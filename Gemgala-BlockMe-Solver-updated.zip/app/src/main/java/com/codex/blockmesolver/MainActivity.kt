package com.codex.blockmesolver

import android.app.Activity
import android.os.Bundle
import android.provider.Settings
import android.content.Intent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 32)
        }
        val title = TextView(this).apply {
            text = "Gemgala BlockMe Solver"
            textSize = 24f
        }
        val info = TextView(this).apply {
            text = "\n1) Enable BlockMe Solver under Android Accessibility.\n" +
                   "2) Open Gemgala → BlockMe.\n" +
                   "3) Return to Gemgala → BlockMe. A visible Scan / Auto* control appears.\n" +
                   "4) Scan shows experimental placement suggestions. Auto* performs gestures.\n\n" +
                   "IMPORTANT: This is an experimental prototype. Piece recognition is hard-coded, so suggestions may be wrong. Only tap Auto* if you accept that risk. The service can capture the screen and perform gestures while enabled."
            textSize = 16f
        }
        val settings = Button(this).apply {
            text = "Open Accessibility Settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(settings)
        setContentView(layout)
    }
}

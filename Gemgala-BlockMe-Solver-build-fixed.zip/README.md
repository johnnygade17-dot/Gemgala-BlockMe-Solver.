# Gemgala BlockMe Solver (build-fixed prototype)

## Build from a phone with GitHub Actions

1. Upload the contents of this ZIP to your GitHub repository (keep the `.github` folder).
2. Open **Actions** and choose **Build Android APK**.
3. Run the workflow, or push a commit to `main`.
4. Open the successful run and download the `Gemgala-BlockMe-Solver-debug` artifact.
5. Extract the ZIP and install `app-debug.apk`.

The workflow uses Java 17, Android SDK 35, and Gradle 8.10.2. It does not require a Gradle wrapper.

## Important limitations

This is a build-fixed prototype, not yet a reliable full auto-solver. The current code uses hardcoded piece silhouettes and fixed screen coordinates. It also lacks a complete in-app trigger/control flow for starting scans and auto-play. A successful build only proves that the APK compiles; it does not prove the puzzle recognition or automated moves work.

Before using automatic gestures, inspect the source and test with a non-sensitive game session. Android Accessibility grants the service the ability to perform gestures.
